import React from 'react'
import Navbar from "../Components/Navbar"
import Hero from '../Components/Hero'
import HomeImg from "../asets/1.jpg"
import Destination from '../Components/Destination'
import Trip from '../Components/Trip'
import Footer from '../Components/Footer'

export default function Home() {
  return ( 
    <div>
      <Navbar/>
      < Hero 
      cName="hero"
      heroImg={HomeImg}
      title="Your Journey Your Story"
      text="Choose your Favourite Destination"
      buttonText="Travel Plan"
      url="/"
      btnClass="show"
      />
     <Destination/>
     <Trip/>
     <Footer/>
    </div>
  )
}
