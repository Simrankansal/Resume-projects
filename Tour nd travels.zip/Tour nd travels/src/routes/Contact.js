import React from 'react'
import Navbar from "../Components/Navbar"
import Hero from '../Components/Hero'
import AboutImg from "../asets/4.jpg"
import Footer from '../Components/Footer'
import ContactForm from '../Components/ContactForm'
export default function Contact() {
  return (
    <div>
      <Navbar/>
      < Hero 
      cName="hero-mid" heroImg={AboutImg}
      title="Contact"
      btnClass="hide"
      />
       <ContactForm/>
      <Footer/>
      
    </div>
  )
}
