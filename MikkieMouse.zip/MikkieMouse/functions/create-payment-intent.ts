require('dotenv').config()

const stripe = require('stripe')(process.env.REACT_APP_STRIPE_SECRET_KEY)

exports.handler = async function (event, context) {
  
  if (event.body) {
    const { cart } = JSON.parse(event.body)
    const calculateTotal = cart => {
      return cart.reduce((total, cartItem) => {
        const { price, amount } = cartItem
        total += amount * price
        return total
      }, 0)
    }

    try {
      const paymentIntent = await stripe.paymentIntents.create({
        amount: calculateTotal(cart) * 100,
        currency: 'thb',
        automatic_payment_methods: {
          enabled: true,
        },
      })

      return {
        statusCode: 200,
        body: JSON.stringify({
          clientSecret: paymentIntent.client_secret,
          amount: paymentIntent.amount,
        }),
      }
    } catch (error) {
      return {
        statusCode: 500,
        body: JSON.stringify({ msg: error.message }),
      }
    }
  } else {
  
    return {
      statusCode: 200,
      body: 'create-payment-intent',
    }
  }
}
