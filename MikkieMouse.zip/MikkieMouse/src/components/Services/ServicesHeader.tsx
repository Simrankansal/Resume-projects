export const ServicesHeader = () => {
  return (
    <article className='header'>
      <h3>
        high quality <br /> baby product
      </h3>
      <p>
      Products which cares for your baby.The best Care for your baby.
      </p>
      <p>We have the following types of products:</p>
    </article>
  )
}
