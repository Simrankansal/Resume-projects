import React from 'react'

export const ContactHeader = () => {
  return <h3>Join our newsletter for new product notification!</h3>
}
