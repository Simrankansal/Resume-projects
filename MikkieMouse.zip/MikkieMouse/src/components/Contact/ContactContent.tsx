import React from 'react'

export const ContactContent = () => {
  return (
    <p>
      Stay informed for new product arrival and get discount by subscribing our
      newsletter.
    </p>
  )
}
