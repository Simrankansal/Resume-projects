import React from 'react'

export const FeaturedProductsHeader = () => {
  return (
    <div className='title'>
      <h2>featured products</h2>
      <div className='underline' />
    </div>
  )
}
