import sanityClient from '@sanity/client'

export default sanityClient({
  projectId: 'bqk6gkzk',
  dataset: 'production',
})