const forWhom = {
  name: 'forWhom',
  title: 'For Whom',
  type: 'document',
  fields: [
    {
      name: 'forWhom',
      title: 'For Whom',
      type: 'string',
    },
  ],
}

export default forWhom
