const age = {
  name: 'age',
  type: 'document',
  fields: [
    {
      name: 'age',
      type: 'string',
    },
  ],
}

export default age
