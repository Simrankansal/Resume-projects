const clothingCategories = {
  name: 'clothingCategories',
  type: 'document',
  fields: [
    {
      name: 'clothingCategories',
      type: 'string',
    },
  ],
}

export default clothingCategories
