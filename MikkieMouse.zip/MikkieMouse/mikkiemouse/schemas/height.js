const height = {
  name: 'height',
  type: 'document',
  fields: [
    {
      name: 'height',
      type: 'string',
    },
  ],
}

export default height
