const categories = {
  name: 'categories',
  type: 'document',
  fields: [
    {
      name: 'categories',
      type: 'string',
    },
  ],
}

export default categories
