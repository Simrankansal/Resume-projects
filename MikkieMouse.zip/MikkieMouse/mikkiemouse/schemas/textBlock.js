const textBlock = {
  name: 'textBlock',
  type: 'array',
  of: [
    {
      type: 'block',
    },
  ],
}

export default textBlock
